const API_TRAIN = "http://apis.baidu.com/qunar/qunar_train_service/";

module.exports = {
    API_TRAIN_SEARCH_ZZ: API_TRAIN+"s2ssearch",
    API_TRAIN_KEY: "361cf2a2459552575b0e86e0f62302bc",
}

