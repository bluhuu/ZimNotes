(function(window) {
	window.api_base_url = '/api'
})(window)