class ellipsisH{
    constructor(){
		this.restrict = 'E'
		this.template = '<ul class="ellipsis-h"><li></li><li></li><li></li></ul>'
		this.replace  = true
    }

    link(scope, element, attrs, controller) {

    }
}

export default ellipsisH