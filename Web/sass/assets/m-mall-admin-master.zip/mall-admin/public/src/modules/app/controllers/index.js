// controllers
import AppController from './app'

export default 
	angular
		.module('app.controller', [])
		.controller('AppController', AppController)