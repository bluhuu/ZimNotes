

Wechat app | 从FlexLayout布局开始


# 布局效果演示

![effect](http://hardog.net/images/assist/20160930/wechat-effect-app-xM.gif)

**[TinyMonit](https://github.com/hardog/tinymonit.git) 集群监控Wechat app实现**

![tm-wechat](http://hardog.net/images/assist/20161008/tm-wechat-example.gif)

