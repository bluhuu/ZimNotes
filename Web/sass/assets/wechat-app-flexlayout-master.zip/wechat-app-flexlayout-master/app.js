//app.js
App({
  globalData: {
    plist: []
  },
  onLaunch: function () {
    console.log('app Launching ...');
  }
});