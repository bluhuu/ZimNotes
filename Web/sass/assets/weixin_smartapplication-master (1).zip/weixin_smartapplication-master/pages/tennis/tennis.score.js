
function score2Love(scoreA, scoreB) {
  
  return "Love All"
}



module.exports.score2Love = score2Love